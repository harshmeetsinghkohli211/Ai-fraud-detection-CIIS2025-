"""
fraud_rule_engine.py

A ready-to-run rule-based + heuristic fraud scoring engine for transactions
with market-awareness (equities/gold) and simple unsupervised signals.

Usage:
    python fraud_rule_engine.py

Outputs:
    DataFrame with appended columns: risk_score, label, reasons
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from datetime import datetime, timedelta

# ------------------------
# Configuration
# ------------------------
CFG = dict(
    AR_thresh=0.04,          # abnormal return threshold (4%)
    zV=3.0,                  # volume z-score threshold
    gap_thresh=0.03,         # price gap threshold
    zSize=3.0,               # trade size z threshold
    v_thresh=5,              # >5 trades in 5 minutes
    deg_thresh=3,
    sd_thresh=2,
    basis_thresh=0.02,       # 2% gold basis
    risk_cut=50,             # risk score cutoff
    # weights for different rules (tune as per data)
    weights=dict(w1=25, w2=20, w2b=15, w3=20, w4=15, w5=10, w6=15, w7=20, w7b=15, w8=15)
)

# ------------------------
# Helpers: Market join & indicators
# ------------------------
def join_market(txn_df, mkt_df):
    """
    Attach nearest market bar (price, volume) info to each transaction.
    mkt_df must have columns: timestamp (datetime), price, volume
    txn_df must have: timestamp
    Returns txn_df with additional columns: price_t, vol_t, ret_1h, vol_z, gap
    """
    if txn_df.empty or mkt_df.empty:
        # Add empty columns and return
        for col in ("price_t", "vol_t", "ret_1h", "vol_z", "gap"):
            txn_df[col] = np.nan
        return txn_df

    # ensure sorted
    mkt = mkt_df.sort_values("timestamp").reset_index(drop=True)
    # compute 1-hour return and rolling vol z for market
    mkt["ret_1h"] = mkt["price"].pct_change(periods=1).fillna(0)  # simple
    mkt["vol_z"] = (mkt["volume"] - mkt["volume"].rolling(20, min_periods=1).mean()) / \
                   (mkt["volume"].rolling(20, min_periods=1).std().replace(0, 1))

    # find nearest market bar for each txn by timestamp
    prices, vols, rets, vol_zs, gaps = [], [], [], [], []
    for ts in pd.to_datetime(txn_df["timestamp"]):
        # find the row with timestamp <= txn timestamp (last available bar)
        idx = mkt.index[mkt["timestamp"] <= ts]
        if len(idx) == 0:
            row = mkt.iloc[0]
        else:
            row = mkt.loc[idx[-1]]
        prices.append(row["price"])
        vols.append(row["volume"])
        rets.append(row["ret_1h"])
        vol_zs.append(row["vol_z"])
        # small gap calc relative to prior bar
        prior_idx = max(0, int(idx[-1]) - 1) if len(idx) else 0
        prior_price = mkt.loc[prior_idx]["price"]
        gap = (row["price"] - prior_price) / max(1e-6, prior_price)
        gaps.append(gap)

    txn_df = txn_df.copy()
    txn_df["price_t"] = prices
    txn_df["vol_t"] = vols
    txn_df["abnormal_ret"] = rets
    txn_df["vol_z"] = vol_zs
    txn_df["gap"] = gaps
    return txn_df

# ------------------------
# User profile features
# ------------------------
def compute_user_profiles(txn_df):
    """
    Compute simple rolling user profile features needed for heuristics:
      - avg_size, size_std, trade_count_1h, last_txn_ts
    Returns DataFrame user_features indexed same as txn_df with columns:
      trade_size_z, vel_5m, vel_1h, is_new_broker_flag (placeholder)
    """
    txn = txn_df.copy()
    txn["amount"] = txn["amount"].astype(float)
    # build quick user aggregates
    users = {}
    for uid, group in txn.groupby("user_id"):
        amounts = group["amount"].values
        users[uid] = {
            "avg": np.mean(amounts) if len(amounts) else 0.0,
            "std": np.std(amounts) if len(amounts) else 1.0,
            "times": pd.to_datetime(group["timestamp"]).sort_values().tolist()
        }

    trade_size_z = []
    vel_5m = []
    vel_1h = []
    new_broker_flag = []
    for _, row in txn.iterrows():
        uid = row["user_id"]
        a = row["amount"]
        prof = users.get(uid, {"avg":0.0, "std":1.0, "times":[]})
        z = (a - prof["avg"]) / (prof["std"] if prof["std"] > 0 else 1.0)
        trade_size_z.append(z)
        # velocity windows
        times = prof["times"]
        ts = pd.to_datetime(row["timestamp"])
        # count events in last 5 min / 1 hour
        cnt5 = sum(1 for t in times if (ts - t) <= pd.Timedelta(minutes=5) and (ts - t) >= pd.Timedelta(0))
        cnt60 = sum(1 for t in times if (ts - t) <= pd.Timedelta(hours=1) and (ts - t) >= pd.Timedelta(0))
        vel_5m.append(cnt5)
        vel_1h.append(cnt60)
        # placeholder for new broker flag (True if broker not previously used) - using broker column
        # for demo: set False
        new_broker_flag.append(False)

    out = pd.DataFrame({
        "trade_size_z": trade_size_z,
        "vel_5m": vel_5m,
        "vel_1h": vel_1h,
        "new_broker_flag": new_broker_flag
    }, index=txn.index)
    return out

# ------------------------
# Network / graph features (mock)
# ------------------------
def network_features(user_id, graph_db=None):
    """
    Placeholder network features. In a real system, graph_db supplies counts.
    Returns: dict with degree_user and shared_device_count
    """
    # For demo, produce deterministic but simple numbers
    # If user_id ends with odd digit -> a higher degree for demo
    deg = int(str(user_id)[-1]) % 5  # 0-4
    shared_device = 1 if deg >= 3 else 0
    return {"degree_user": deg, "shared_device_count": shared_device}

# ------------------------
# Simple unsupervised scores (IsolationForest)
# ------------------------
def unsup_scores(feature_df):
    """
    Fit an IsolationForest on provided feature_df and return iso scores normalized [0,1].
    This function fits on the training-like feature set; for demo we fit on full set.
    """
    if feature_df.shape[0] < 5:
        # not enough rows
        return np.zeros(feature_df.shape[0])
    iso = IsolationForest(n_estimators=100, contamination=0.01, random_state=42)
    iso.fit(feature_df)
    # score_samples: higher is normal -> invert
    raw = -iso.score_samples(feature_df)  # higher = more anomalous
    # normalize 0..1
    minv, maxv = raw.min(), raw.max()
    if maxv - minv <= 0:
        return np.zeros_like(raw)
    return (raw - minv) / (maxv - minv)

# ------------------------
# Domain helpers (smallcap, roundtrip, burst)
# ------------------------
def is_smallcap(symbol):
    """Simplified small-cap check (demo). Real: use market cap lookup."""
    # demo rule: symbols starting with 'S' are smallcap
    return str(symbol).upper().startswith("S")

def has_roundtrip(txn_df_user, symbol, window_minutes=30):
    """
    Detect buy and sell of same symbol within window for the same user.
    txn_df_user is transactions for that user.
    """
    df = txn_df_user[txn_df_user["symbol"] == symbol].sort_values("timestamp")
    # naive scan
    for i in range(len(df)-1):
        t1 = pd.to_datetime(df.iloc[i]["timestamp"])
        t2 = pd.to_datetime(df.iloc[i+1]["timestamp"])
        side1 = df.iloc[i]["side"]
        side2 = df.iloc[i+1]["side"]
        if side1 != side2 and (t2 - t1) <= pd.Timedelta(minutes=window_minutes):
            return True
    return False

def burst_small_buys_then_large_opposite(txn_df_user, symbol, burst_minutes=10):
    """
    Detect pattern: many small buys then a large sell (or reverse).
    """
    df = txn_df_user[txn_df_user["symbol"] == symbol].sort_values("timestamp")
    if df.empty: 
        return False
    # simple aggregation in last burst_minutes
    now = pd.to_datetime(df["timestamp"].iloc[-1])
    window_df = df[df["timestamp"] >= (now - pd.Timedelta(minutes=burst_minutes)).astype(str)]
    buys = window_df[window_df["side"].str.lower() == "buy"]
    sells = window_df[window_df["side"].str.lower() == "sell"]
    if len(buys) >= 3 and (sells["amount"].sum() > buys["amount"].sum() * 2):
        return True
    return False

# ------------------------
# Scoring rules ladder
# ------------------------
def score_transaction(row, txn_group_by_user):
    """
    Evaluate a single transaction row (Series) using rule ladder.
    txn_group_by_user: DataFrame of transactions for the same user (all rows)
    Returns: (risk_score:int, label:str, reasons:list)
    """
    W = CFG["weights"]
    score = 0
    reasons = []

    # R1: Insider-like (pre-move) - abnormal_ret & is_pre_move (we mark pre_move if above)
    if abs(row.get("abnormal_ret", 0.0)) > CFG["AR_thresh"] and row.get("is_pre_move", False):
        score += W["w1"]; reasons.append("Pre-move trade near abnormal return")

    # R2: Pump & Dump signature
    elif row.get("vol_z", 0) is not None and row.get("vol_z", 0) > CFG["zV"] \
         and row.get("gap", 0) > CFG["gap_thresh"] and is_smallcap(row.get("symbol", "")):
        score += W["w2"]; reasons.append("Pump-like conditions (high volume + gap + small-cap)")
        if row.get("quick_profit_dump", False):
            score += W["w2b"]; reasons.append("Quick dump after pump")

    # R3: Wash/round-trip
    elif has_roundtrip(txn_group_by_user, row.get("symbol", ""), window_minutes=30):
        score += W["w3"]; reasons.append("Round-trip behavior (buy -> sell quickly)")

    # R4: Layering / burst pattern
    elif burst_small_buys_then_large_opposite(txn_group_by_user, row.get("symbol", ""), burst_minutes=10):
        score += W["w4"]; reasons.append("Layering-like burst pattern")

    # R5: Behavioral anomaly vs user profile
    elif row.get("trade_size_z", 0) > CFG["zSize"] or row.get("vel_5m", 0) > CFG["v_thresh"] or row.get("new_broker_flag", False):
        score += W["w5"]; reasons.append("Behavioral anomaly vs user baseline")

    # R6: Network risk features
    elif row.get("degree_user", 0) > CFG["deg_thresh"] or row.get("shared_device_count", 0) > CFG["sd_thresh"]:
        score += W["w6"]; reasons.append("Network linkage risk (shared device/degree high)")

    # R7: Gold / SGB specific patterns
    elif str(row.get("symbol", "")).upper() in ("GOLD", "SGB"):
        # quick proxy checks; in real system use NAV & spot lookup
        if abs(row.get("gold_spot", 0) - row.get("sgb_nav", 0)) / max(1e-6, row.get("gold_spot", 1)) > CFG["basis_thresh"] \
           and row.get("amount", 0) > 100000 and row.get("quick_reversal", False):
            score += W["w7"]; reasons.append("Gold basis exploit / layering proxy")
        if row.get("cash_to_gold_to_cash", False):
            score += W["w7b"]; reasons.append("Cash->Gold->Cash layering")

    # R8: Unsupervised anomaly score (fallback)
    else:
        iso_score = row.get("iso_score", 0)
        if iso_score > 0.7:
            score += W["w8"]; reasons.append("High unsupervised anomaly score")

    label = "SUSPICIOUS" if score >= CFG["risk_cut"] else "NORMAL"
    return int(score), label, reasons

# ------------------------
# Main pipeline
# ------------------------
def run_rule_engine(txn_df, market_equity_df=None, market_gold_df=None, verbose=False):
    """
    Full pipeline:
      - join market data
      - compute user profiles
      - compute network features
      - compute unsupervised scores
      - apply rule ladder per txn
    Returns DataFrame with appended risk columns.
    """
    txn = txn_df.copy().reset_index(drop=True)
    # 1) Market join (equity)
    if market_equity_df is not None:
        txn = join_market(txn, market_equity_df)
    else:
        # add empty defaults
        txn["price_t"] = np.nan
        txn["vol_t"] = np.nan
        txn["abnormal_ret"] = 0.0
        txn["vol_z"] = 0.0
        txn["gap"] = 0.0

    # Mark pre_move flag: here a simple heuristic (abs(ret) > half AR_thresh)
    txn["is_pre_move"] = txn["abnormal_ret"].abs() > (CFG["AR_thresh"] / 2)

    # 2) user profile features
    user_feats = compute_user_profiles(txn)
    txn = pd.concat([txn, user_feats], axis=1)

    # 3) network features per user
    net_feats = txn["user_id"].apply(lambda u: pd.Series(network_features(u)))
    txn = pd.concat([txn, net_feats.reset_index(drop=True)], axis=1)

    # 4) gold info (if supplied)
    if market_gold_df is not None:
        # simplified: map sgb_nav and spot via nearest timestamp in market_gold_df
        s_spots, s_navs = [], []
        mg = market_gold_df.sort_values("timestamp").reset_index(drop=True)
        for ts in pd.to_datetime(txn["timestamp"]):
            idx = mg.index[mg["timestamp"] <= ts]
            if len(idx) == 0:
                r = mg.iloc[0]
            else:
                r = mg.loc[idx[-1]]
            s_spots.append(r["spot"])
            s_navs.append(r.get("nav", r["spot"]))
        txn["gold_spot"] = s_spots
        txn["sgb_nav"] = s_navs
    else:
        txn["gold_spot"] = np.nan
        txn["sgb_nav"] = np.nan

    # 5) unsupervised anomaly scores: fit on numeric feature set
    numeric_cols = ["amount", "price_t", "vol_t", "abnormal_ret", "vol_z", "gap", "trade_size_z", "vel_5m", "vel_1h"]
    numeric = txn[numeric_cols].fillna(0.0)
    txn["iso_score"] = unsup_scores(numeric)

    # 6) group by user for convenience in rules
    results = []
    for idx, row in txn.iterrows():
        user_id = row["user_id"]
        user_group = txn[txn["user_id"] == user_id]
        score, label, reasons = score_transaction(row.to_dict(), user_group)
        results.append((score, label, "; ".join(reasons)))

    txn[["risk_score", "label", "reasons"]] = pd.DataFrame(results, index=txn.index)
    if verbose:
        print(txn[["txn_id", "user_id", "symbol", "amount", "risk_score", "label", "reasons"]])
    return txn

# ------------------------
# Demo: synthetic data and run
# ------------------------
def make_synthetic_demo():
    """Create small synthetic transaction + market datasets for demo purposes."""
    now = datetime.utcnow().replace(second=0, microsecond=0)
    txns = [
        # normal user, regular amounts
        {"txn_id": "T1", "user_id": "U100", "timestamp": now - timedelta(minutes=30), "amount": 700, "symbol": "NIL", "side": "credit"},
        {"txn_id": "T2", "user_id": "U100", "timestamp": now - timedelta(minutes=10), "amount": 650, "symbol": "NIL", "side": "credit"},
        {"txn_id": "T3", "user_id": "U100", "timestamp": now, "amount": 800, "symbol": "NIL", "side": "credit"},
        # suspicious user: burst of large transfers to same beneficiary / trades in small-cap
        {"txn_id": "T4", "user_id": "U200", "timestamp": now - timedelta(minutes=5), "amount": 50000, "symbol": "SXYZ", "side": "sell"},
        {"txn_id": "T5", "user_id": "U200", "timestamp": now - timedelta(minutes=4), "amount": 48000, "symbol": "SXYZ", "side": "buy"},
        {"txn_id": "T6", "user_id": "U200", "timestamp": now - timedelta(minutes=3), "amount": 51000, "symbol": "SXYZ", "side": "sell"}
    ]
    txn_df = pd.DataFrame(txns)
    # market equity: create bars each minute
    times = [now - timedelta(minutes=i) for i in range(60, -1, -1)]
    prices = np.linspace(100, 120, len(times)) + np.random.normal(0, 0.5, len(times))
    volumes = np.random.poisson(lam=1000, size=len(times)) + np.random.randint(0, 500, len(times))
    mkt = pd.DataFrame({"timestamp": times, "price": prices, "volume": volumes})
    # simple gold market (spot + nav)
    gtimes = times
    spots = np.linspace(5000, 5050, len(gtimes)) + np.random.normal(0, 1, len(gtimes))
    navs = spots * (1 + np.random.normal(0, 0.001, len(gtimes)))
    mg = pd.DataFrame({"timestamp": gtimes, "spot": spots, "nav": navs})
    return txn_df, mkt, mg

if __name__ == "__main__":
    # Demo run
    txn_df, mkt_eq, mkt_gold = make_synthetic_demo()
    scored = run_rule_engine(txn_df, market_equity_df=mkt_eq, market_gold_df=mkt_gold, verbose=True)
    print("\n--- Scored Transactions ---")
    print(scored[["txn_id", "user_id", "amount", "symbol", "risk_score", "label", "reasons"]].to_string(index=False))
