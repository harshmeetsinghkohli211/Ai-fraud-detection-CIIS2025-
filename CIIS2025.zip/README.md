# 🛡️ Smart Fraud Detection System

A **rule-based + machine learning hybrid fraud detection framework** designed for UPI, stock market, and gold bond transactions.  
The system leverages **market indicators, user behavior profiling, network analysis, and anomaly detection (IsolationForest)** to flag suspicious activities in financial data.  

This project is built to demonstrate how fraud detection can be extended beyond simple UPI transaction checks into **multi-domain monitoring (banking, equities, gold bonds)**, while remaining explainable and flexible for research or deployment.

---

## 🚀 Features
- **Transaction Monitoring**: Analyze passbook/bank entries with timestamps, amounts, and symbols.  
- **Market Awareness**: Detect pump-and-dump or insider-like trades by linking to market equity/gold data.  
- **User Profiling**: Compare transactions against user’s normal trade size, velocity, and broker behavior.  
- **Network Features**: Capture shared devices & graph-style connections between accounts.  
- **Unsupervised Anomaly Detection**: IsolationForest to flag rare/unusual transactions.  
- **Explainability**: Each flagged transaction includes a `reason` and `risk_score`.  

---

## 📂 Repository Structure
